// import { test, expect } from '@playwright/test';

// test('has title', async ({ page }) => {
//   await page.goto('/');

//   // Expect a title "to contain" a substring.
//   // This is a placeholder expectation as I don't know the exact title,
//   // but this verifies the test runner can reach the page.
//   await expect(page).toHaveTitle(/Chess|App|Anything/i);
// });

// test('onboarding flow redirect', async ({ page }) => {
//   await page.goto('/onboarding/welcome');
//   await expect(page.getByText('Welcome')).toBeVisible();
// });
